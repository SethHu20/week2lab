package com.example.week2lab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText titleInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titleInput = findViewById(R.id.titleInput);

    }

    public void addMovie(View view) {
        String title = titleInput.getText().toString();
        Toast.makeText(
                getApplicationContext(),
                "Movie - " + title + " - has been added",
                Toast.LENGTH_LONG
        ).show();
    }
}